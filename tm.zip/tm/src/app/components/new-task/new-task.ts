import { Component } from '@angular/core';
import { TaskService } from '../../task';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-new-task',
  imports: [FormsModule],
  templateUrl: './new-task.html',
  styleUrl: './new-task.css'
})
export class NewTask {
  
title = '';
  description = '';

  constructor(private taskService: TaskService, private router: Router) {}

  createTask() {
    this.taskService.addTask({ title: this.title, description: this.description });
    this.title = '';
    this.description = '';
    alert('Task Created!');
  }
}
