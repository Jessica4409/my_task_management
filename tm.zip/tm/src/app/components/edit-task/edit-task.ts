import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TaskService } from '../../task';
import { Task } from '../../task.model';

@Component({
  selector: 'app-edit-task',
  imports: [],
  templateUrl: './edit-task.html',
  styleUrl: './edit-task.css'
})

export class EditTask implements OnInit {
  task: Task | undefined;
  title = '';
  description = '';

  constructor(
    private route: ActivatedRoute,
    private taskService: TaskService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.task = this.taskService.getTaskById(id);
    if (this.task) {
      this.title = this.task.title;
      this.description = this.task.description;
    }
  }

  updateTask() {
    if (this.task) {
      this.taskService.updateTask(this.task.id, { title: this.title, description: this.description });
      alert('Task Updated!');
      this.router.navigate(['/new-task']);
    }
  }
}

