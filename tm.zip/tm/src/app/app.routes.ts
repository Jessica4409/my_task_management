import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { NewTask } from './components/new-task/new-task';
import { EditTask } from './components/edit-task/edit-task';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { Home } from './home/home';

export const routes: Routes = [
    { path: 'home', component: Home },
    { path: 'new-task', component: NewTask },
    { path: 'edit-task/:id', component: EditTask },
    { path: '', redirectTo: '/home', pathMatch: 'full' }
];


@NgModule({
  imports: [RouterModule.forRoot(routes),  BrowserModule,
    FormsModule ],
  exports: [RouterModule]
})
export class AppRoutingModule { }