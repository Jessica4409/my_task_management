import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; // <-- Add this import
import { TaskService } from '../task';
import { Router } from '@angular/router';
import { Task } from '../task.model';
import { NewTask } from '../components/new-task/new-task';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, NewTask], // <-- Add CommonModule here
  templateUrl: './home.html',
  styleUrl: './home.css'
})
export class Home implements OnInit {
  tasks: Task[] = [];

  constructor(private taskService: TaskService, private router: Router) {}

  ngOnInit() {
    this.tasks = this.taskService.getTasks();
  }

  editTask(id: number) {
    this.router.navigate(['/edit-task', id]);
  }

  deleteTask(id: number) {
    this.taskService.deleteTask(id);
    this.tasks = this.taskService.getTasks();
  }
}
